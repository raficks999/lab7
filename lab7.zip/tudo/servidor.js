
"use strict";

const express = require("express");
const path = require("path");

const app = express();
const PORT = 80;

// Códigos ANSI para colorir o terminal
const cores = {
    reset: "\x1b[0m",
    verde: "\x1b[32m",
    azul: "\x1b[34m",
    amarelo: "\x1b[33m",
    ciano: "\x1b[36m",
    negrito: "\x1b[1m"
};

// Disponibiliza os arquivos do site
app.use(express.static(__dirname));

// Inicia o servidor
app.listen(PORT, "0.0.0.0", () => {
    console.log(
        `${cores.verde}${cores.negrito}✓ Servidor rodando!${cores.reset}`
    );

    console.log(
        `${cores.ciano}➜ Porta:${cores.reset} ${cores.amarelo}${PORT}${cores.reset}`
    );

    console.log(
        `${cores.azul}➜ Site local:${cores.reset} http://localhost/Home.html`
    );

    console.log(
        `${cores.verde}➜ Servidor pronto para receber conexões!${cores.reset}`
    );
});
